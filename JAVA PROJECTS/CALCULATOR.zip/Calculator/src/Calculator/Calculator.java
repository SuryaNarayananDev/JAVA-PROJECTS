//created by Suryanarayanan.S
package Calculator;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Calculator implements ActionListener{
	JFrame jf;
	JLabel displaybox;
	JButton buttonclear,buttonNull,button7,button8,button9,buttonPlus,button4,button5,button6,Sub,button1,button2,button3,buttonMul,Dot,button0, Divison,Equal;
	boolean isopClick=false;
	String preValue;
	String newValue;
	int operator;
	int OneOprator=0;
	float sumFunction;
	float preValueF;
	float newValueF,Result;
	
public Calculator()
{
	jf=new JFrame("Calculator");
	jf.setLayout(null);
	jf.setSize(420,606);
	jf.setLocation(450,50);
	jf.getContentPane().setBackground(Color.black);
	
    displaybox=new JLabel("");
	displaybox.setBounds(0,20,406,100);
	displaybox.setBackground(Color.black);
	displaybox.setOpaque(true);
	displaybox.setHorizontalAlignment(SwingConstants.RIGHT);
	displaybox.setForeground(Color.white);
	displaybox.setFont(new Font("Times New Roman", Font.PLAIN, 40));
	jf.add(displaybox);
	
	//Row 4
    
    button7=new JButton("7");
    button7.setBounds(0,120,100,100);
    button7.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button7.setBackground(Color.gray);
    button7.setForeground(Color.black);
    button7.addActionListener(this);
    jf.add(button7);
    

    button8=new JButton("8");
    button8.setBounds(102,120,100,100);
    button8.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button8.setBackground(Color.gray);
    button8.setForeground(Color.black);
    button8.addActionListener(this);
    jf.add(button8);
    
    button9=new JButton("9");
    button9.setBounds(204,120,100,100);
    button9.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button9.setBackground(Color.gray);
    button9.setForeground(Color.black);
    button9.addActionListener(this);
    jf.add(button9);
    
    buttonPlus=new JButton("+");
    buttonPlus.setBounds(307,222,100,100);
    buttonPlus.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    buttonPlus.setBackground(new Color(240, 154, 5));
    buttonPlus.setForeground(Color.black);
    buttonPlus.addActionListener(this);
    jf.add(buttonPlus);
    
    
    
//Row 3
    
    button4=new JButton("4");
    button4.setBounds(0,222,100,100);
    button4.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button4.setBackground(Color.gray);
    button4.setForeground(Color.black);
    button4.addActionListener(this);
    jf.add(button4);
    

    button5=new JButton("5");
    button5.setBounds(102,222,100,100);
    button5.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button5.setBackground(Color.gray);
    button5.setForeground(Color.black);
    button5.addActionListener(this);
    jf.add(button5);
    
    button6=new JButton("6");
    button6.setBounds(204,222,100,100);
    button6.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button6.setBackground(Color.gray);
    button6.setForeground(Color.black);
    button6.addActionListener(this);
    jf.add(button6);
    
    Sub=new JButton("-");
    Sub.setBounds(307,120,100,100);
    Sub.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    Sub.setBackground(new Color(240, 154, 5));
    Sub.setForeground(Color.black);
    Sub.addActionListener(this);
    jf.add(Sub);
    
//Row 2
    
    button1=new JButton("1");
    button1.setBounds(0,324,100,100);
    button1.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button1.setBackground(Color.gray);
    button1.setForeground(Color.black);
    button1.addActionListener(this);
    jf.add(button1);
    

    button2=new JButton("2");
    button2.setBounds(102,324,100,100);
    button2.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button2.setBackground(Color.gray);
    button2.setForeground(Color.black);
    button2.addActionListener(this);
    jf.add(button2);
    
    button3=new JButton("3");
    button3.setBounds(204,324,100,100);
    button3.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button3.setBackground(Color.gray);
    button3.setForeground(Color.black);
    button3.addActionListener(this);
    jf.add(button3);
    
    buttonMul=new JButton("x");
    buttonMul.setBounds(307,324,100,100);
    buttonMul.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    buttonMul.setBackground(new Color(240, 154, 5));
    buttonMul.setForeground(Color.black);
    buttonMul.addActionListener(this);
    jf.add(buttonMul);
    
//Row 1
    
    Dot=new JButton(".");
    Dot.setBounds(0,426,100,100);
    Dot.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    Dot.setBackground(Color.gray);
    Dot.setForeground(Color.black);
    Dot.addActionListener(this);
    jf.add(Dot);
    

    button0=new JButton("0");
    button0.setBounds(102,426,100,100);
    button0.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    button0.setBackground(Color.gray);
    button0.setForeground(Color.black);
    button0.addActionListener(this);
    jf.add(button0);
    
    Divison=new JButton("/");
    Divison.setBounds(204,426,100,100);
    Divison.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    Divison.setBackground(new Color(240, 154, 5));
    Divison.setForeground(Color.black);
    Divison.addActionListener(this);
    jf.add( Divison);
    
    Equal=new JButton("=");
    Equal.setBounds(307,426,100,100);
    Equal.setFont(new Font("Times New Roman", Font.PLAIN, 40));
    Equal.setBackground(new Color(240, 154, 5));
    Equal.setForeground(Color.black);
    
    Equal.addActionListener(this);
    jf.add(Equal);
    
    buttonclear=new JButton("Clear");
    buttonclear.setBounds(204,528,200,50);
    buttonclear.setFont(new Font("Times New Roman", Font.PLAIN, 30));
    buttonclear.setBackground(Color.cyan);
    buttonclear.setForeground(Color.black);
    buttonclear.addActionListener(this);
    jf.add(buttonclear);
    
    buttonNull=new JButton();
    buttonNull.setBounds(0,528,202,50);
    buttonNull.setFont(new Font("Times New Roman", Font.PLAIN, 30));
    buttonNull.setBackground(Color.cyan);
    buttonNull.setForeground(Color.black);
    jf.add(buttonNull);

	jf.setVisible(true);
	jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
}

public static void main(String ar[])
{
	new Calculator();
}
@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==button7) {
	if(isopClick) {
		displaybox.setText("7");
		isopClick=false;
		}
	else {
		displaybox.setText(displaybox.getText()+"7");
	     }
	}
	else if(e.getSource()==button8) {
		if(isopClick) {
			displaybox.setText("8");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"8");
		     }
	}
	else if(e.getSource()==button9) {
		if(isopClick) {
			displaybox.setText("9");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"9");
		     }
	}
	else if(e.getSource()==button4) {
		if(isopClick) {
			displaybox.setText("4");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"4");
		     }
	}
	else if(e.getSource()==button5) {
		if(isopClick) {
			displaybox.setText("5");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"5");
		     }
	}
	else if(e.getSource()==button6) {
		if(isopClick) {
			displaybox.setText("6");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"6");
		     }
	}
   else if(e.getSource()==button1) {
	   if(isopClick) {
			displaybox.setText("1");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"1");
		     }
	}
	else if(e.getSource()==button2) {
		if(isopClick) {
			displaybox.setText("2");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"2");
		     }
	}
	else if(e.getSource()==button3) {
		if(isopClick) {
			displaybox.setText("3");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"3");
		     }
	}
  else if(e.getSource()==Dot) {
	  if(isopClick) {
			displaybox.setText("0.");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+".");
		     }
    }
 else if(e.getSource()==button0) {
		if(isopClick) {
			displaybox.setText("");
			isopClick=false;
			}
		else {
			displaybox.setText(displaybox.getText()+"0");
		     }
	}
	else if(e.getSource()==buttonclear) {
		displaybox.setText("");
		zeroValue();
	}
	else if(e.getSource()==Equal) {
		newValue=displaybox.getText();
		preValueF=Float.parseFloat(preValue);
		newValueF=Float.parseFloat(newValue);
		CallEqual(preValueF, newValueF,operator);
		}
	
	//operators
	
	else if(e.getSource()==Sub) {
		if(OneOprator==0) {
		 preValue=displaybox.getText();
		 isopClick=true;
		 operator=2;
		 OneOprator=1;
		} else if(operator==2) {
			  newValue=displaybox.getText();
				preValueF=Float.parseFloat(preValue);
				newValueF=Float.parseFloat(newValue);
				CallEqual(preValueF, newValueF,operator);
			  }
			  else {
				  displaybox.setText("[ ! Only One Operator can Use ! ]");
			  }
		
	}
	
	  else if(e.getSource()==buttonMul) {
		  if(OneOprator==0) {
		  preValue=displaybox.getText();
			 isopClick=true;
			 operator=3;
		     OneOprator=1;
		  }
		  else if(operator==3) {
			  newValue=displaybox.getText();
				preValueF=Float.parseFloat(preValue);
				newValueF=Float.parseFloat(newValue);
				CallEqual(preValueF, newValueF,operator);
			  }
			  else {
				  displaybox.setText("[ ! Only One Operator can Use ! ]");
			  }
	    }
	
	  else if(e.getSource()==Divison) {
		  if(OneOprator==0) {
		  preValue=displaybox.getText();
			 isopClick=true;
			 operator=4;
			 OneOprator=1;
		  } else if(operator==4) {
			  newValue=displaybox.getText();
				preValueF=Float.parseFloat(preValue);
				newValueF=Float.parseFloat(newValue);
				CallEqual(preValueF, newValueF,operator);
			  }
			  else {
				  displaybox.setText("[ ! Only One Operator can Use ! ]");
			  }
		}
	
	  else if(e.getSource()==buttonPlus) {
		  if(OneOprator==0) {
		 preValue=displaybox.getText();
		 isopClick=true;
		 operator=1;
		 OneOprator=1;
		  } else if(operator==1) {
			  newValue=displaybox.getText();
				preValueF=Float.parseFloat(preValue);
				newValueF=Float.parseFloat(newValue);
				CallEqual(preValueF, newValueF,operator);
			  }
		  else {
			  displaybox.setText("[ ! Only One Operator can Use ! ]");
		  }
		}
}
public void zeroValue() {
	preValueF=0;
	newValueF=0;
	preValue="";
	newValue="";
	Result=0;
	operator=0;
	OneOprator=0;
	isopClick=false;
}
public void CallEqual(float x,float y,int a)
{
	switch(a)
	{
	case 1:Result=preValueF+newValueF;
	       displaybox.setText(Result+"");
	       zeroValue();
	       
		break;
	case 2:Result=preValueF-newValueF;
           displaybox.setText(Result+"");
           zeroValue();
           
		break;
	case 3:Result=preValueF*newValueF;
           displaybox.setText(Result+"");
           zeroValue();
           
		break;
	case 4:Result=preValueF/newValueF;
           displaybox.setText(Result+"");
           zeroValue();
           
		break;
	}
	
	
}
}


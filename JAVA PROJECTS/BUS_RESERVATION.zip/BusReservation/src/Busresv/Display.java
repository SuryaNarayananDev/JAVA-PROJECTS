package Busresv;

import java.util.ArrayList;
import java.util.Scanner;

public class Display {

	 public static void main(String ar[])
	 {
		 ArrayList<Bus> Buses= new ArrayList<Bus>();
		 Buses.add(new Bus(2877,45,true));
		 Buses.add(new Bus(5455,50,true));
		 Buses.add(new Bus(8457,48,true));
		 Buses.add(new Bus(8745,35,true));
		 
		 //////////////////////////////////////
		 ArrayList<Booking> bookings= new ArrayList<Booking>();
		 
		 
		 //////////////////////////////////////
		 
		 for(Bus b:Buses)
		 {
			 b.DisplayBusinfo();
		 }
		 
		 Scanner scan=new Scanner(System.in);
		 int Choice=1;
		 System.out.print("=======[ WELCOME TO SURYA TRAVELS ]======\n");
		 while (Choice==1) {
			 System.out.println("\n   OPTION   \nEnter 1 FOR BOOKING.\nEnter 2 FOR EXIT.");
			 Choice=scan.nextInt();
			 
			 if(Choice==1)
             {
				 
				 System.out.print("BOOKING >..>..>..>\n\n");
				 Booking booking=new Booking();
				 if(booking.isAvailable(bookings,Buses))
				 {
					 bookings.add(booking);
					 System.out.println("\n================[ YOUR BUS SEAT WAS BOOKED SUCCESSFULLY ]================\n================[ HAVE A GOOD TRIP SIR ]================");
					 
					 
				 }
			  else 
			  {
					 System.out.print("Seat was Fully Booked . Please Check anther date For your Journey (^_^)\n\n");
			  }
             }
			 else 
			 {
				 System.out.print("   === [ THANK YOU ] ===   ");
				 
			 }
		
		 }
		 
		 
	 }
}

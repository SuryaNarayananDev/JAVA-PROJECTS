package Busresv;

import java.util.Date;

public class Bus {
	private int BusNumber;
	private Date date;
    private	int capacity;
    private boolean Ac;
	
    Bus(int No,int cap,boolean x)
    {
    	this.BusNumber=No;
    	this.capacity=cap;
    	this.Ac=x;
    }
    
    public int getCapacity() {
		return capacity;
		
	}
    
    public void setCapacity(int cap)
    {
    	capacity=cap;
    }

    public void setAc(boolean x) 
    {
       	Ac=x;
    }
    
    public boolean getAc()
    {
    	return Ac;
    }
    
    public int getNumber()
    {
    	return BusNumber;
    	
    }
    public void DisplayBusinfo()
    {
    	System.out.print("BUS NUMBER : "+BusNumber+".\nDATE : "+date+".\nBUS WITH AIRCOOLER : "+Ac+".\nCAPACITY : "+capacity+".\n=============================================\n");
    }
    
  
}

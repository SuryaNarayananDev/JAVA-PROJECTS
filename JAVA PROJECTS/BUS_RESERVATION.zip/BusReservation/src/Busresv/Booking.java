package Busresv;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Booking {
String PassName;
Date date;
int BusNo;
Booking()
{
	Scanner scan=new Scanner(System.in);
	System.out.print("Enter Passenger Name :");
	PassName=scan.next();
	System.out.print("Enter Bus Number :");
	BusNo=scan.nextInt();
	
	System.out.print("Enter Date (DD-MM-YYYY) :");
	String dateInput =scan.next();
	SimpleDateFormat dateformat = new SimpleDateFormat("dd-mm-yyyy");
	try {
		
		date =dateformat.parse(dateInput);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
public boolean isAvailable(ArrayList<Booking> bookings, ArrayList<Bus> buses) {
	int cap=0;
	int booked=0;
	for(Bus bus:buses)
	{
		if(bus.getNumber()== BusNo);
		{
			cap=bus.getCapacity();
		}
	}	
	for(Booking b:bookings)
	{
		if(b.BusNo==BusNo && b.date.equals(date))
		{
			booked++;
		}
	}
		return booked<cap?true:false;
		
}

}




